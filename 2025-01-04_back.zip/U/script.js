

```javascript
function displayCurrentTime() {
    // 获取当前时间
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();
    
    // 格式化时间，保证是一位数时前面有0
    hours = hours < 10 ? '0' + hours : hours;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    
    // 构建时间字符串
    var currentTime = hours + ':' + minutes + ':' + seconds;
    
    // 将时间显示在网页上
    document.getElementById('timeDisplay').innerText = currentTime;
}

// 可选：页面加载时自动显示一次时间
window.onload = function() {
    displayCurrentTime();
    setInterval(displayCurrentTime, 1000); // 每秒更新一次时间
}
```