<?php
 echo '欢迎使用WebCat';
?>